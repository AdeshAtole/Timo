package com.example.projectqwerty001;

import java.util.Date;

public class TimeRange {
	Date startTime, endTime;

	public TimeRange(Date startTime, Date endTime) {
		// TODO Auto-generated constructor stub
		this.startTime = startTime;
		this.endTime = endTime;
	}
}
