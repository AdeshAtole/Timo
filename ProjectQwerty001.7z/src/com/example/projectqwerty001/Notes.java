package com.example.projectqwerty001;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Notes extends Activity implements OnItemClickListener {

	ListView lvSubList;
	ArrayList<String> subjectArrayList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.subject_notes);
		init();
		ApplicationDatabase aadb = new ApplicationDatabase(this);
		aadb.open();
		subjectArrayList = aadb.getSubjects();
		aadb.close();
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, subjectArrayList);
		lvSubList.setAdapter(adapter);
	}

	private void init() {
		lvSubList = (ListView) findViewById(R.id.lvSubjectList_Notes);
		lvSubList.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position,
			long arg3) {
		// TODO Auto-generated method stub
		String a = subjectArrayList.get(position);
		Toast.makeText(getApplicationContext(), a, Toast.LENGTH_SHORT).show();
	}
}
