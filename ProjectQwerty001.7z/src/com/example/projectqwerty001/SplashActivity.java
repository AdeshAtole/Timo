package com.example.projectqwerty001;

import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class SplashActivity extends Activity {

	public static final String SHARED_PREFERENCES_FILENAME = "TimoPreferences";
	public static final String KEY_USER_TYPE = "KEY_USER_TYPE";
	public static final String KEY_SUBJECT_LIST = "KEY_SUBJECT_LIST";
	public static final String KEY_LATITUDE = "KEY_LAT";
	public static final String KEY_LONGITUDE = "KEY_LON";
	public static final String KEY_FLAG_LOCATION_BASED = "LOCATION_BASED";
	public static final String KEY_FLAG_TIME_BASED = "TIME_BASED";
	public static final int USER_CR = 1;
	public static final int USER_STUDENT = 2;
	public static final int USER_UNKNOWN = 3;
	public static Typeface robotoThin, robotoLight;
	public static String APPLICATION_PATH = null;
	public static final String DROPBOX_APP_KEY = "p78hpiyefxd4p9z";
	public static final String DROPBOX_APP_SECRET = "hwjzoa1qoxjoqft";
	protected static final String KEY_PROXIMITY_RADIUS = "PROXIMITY_RADIUS";
	public static final String KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_SUBJECT_NAME = "TIMETABLE_ENTRY_INFO_SUBJECT";
	public static final String KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME = "TIMETABLE_START_TIME";
	public static final String KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_ENDTIME = "TIMETABLE_END_TIME";
	protected static final String KEY_SETUP_COMPLETED = "KEY_SETUP_COMPLETED";
	// public static LocationManager locationManager;
	public static String NOTICE_PATH = null;

	TextView title, appVersion;
	Thread myThread;
	private final static int SPLASH_DURATION = 5000;
	SharedPreferences userPref;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		makeFullScreenActivity();
		setContentView(R.layout.splash);
		init();
		title.setTypeface(robotoThin);
		appVersion.setTypeface(robotoThin);

		myThread = new Thread() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				super.run();
				try {
					sleep(SPLASH_DURATION);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {

					if (userPref.getBoolean(KEY_SETUP_COMPLETED, false) == false) {
						File folder = new File(
								Environment.getExternalStorageDirectory()
										+ "/com.minic.timo");
						if (!folder.exists()) {
							boolean b = folder.mkdir();
							if (b == true) {
								Log.i("TIMO", "App Directory created");
							} else {
								Log.i("TIMO", "App Directory not created");
							}
						}
						File noticeFolder = new File(
								Environment.getExternalStorageDirectory()
										+ "/com.minic.timo/_notice");
						if (!noticeFolder.exists()) {
							boolean b = noticeFolder.mkdir();
							if (b) {
								Log.i("TIMO", "Notice Folder Created");
							} else {
								Log.i("TIMO", "Noticce folder creation failed");
							}
						}

					}

					NOTICE_PATH = Environment.getExternalStorageDirectory()
							+ "/com.minic.timo/_notice";
					APPLICATION_PATH = Environment
							.getExternalStorageDirectory() + "/com.minic.timo";

					Log.i("DIR", "App Path : " + APPLICATION_PATH);

					int user = userPref.getInt(KEY_USER_TYPE, USER_UNKNOWN);

					if (userPref.getBoolean(KEY_SETUP_COMPLETED, false)) {
						startActivity(new Intent(
								"com.example.projectqwerty001.HOMESCREEN"));

						return;
					}

					// Toast.makeText(
					// getApplicationContext(),
					// ""
					// + userPref.getBoolean(KEY_SETUP_COMPLETED,
					// false), Toast.LENGTH_SHORT).show();
					Log.d("TIMO",
							"Setup Completed : "
									+ userPref.getBoolean(KEY_SETUP_COMPLETED,
											false));

					Intent myActivityIntent = null;
					switch (user) {
					case USER_UNKNOWN:
						myActivityIntent = new Intent(
								"com.example.projectqwerty001.SELECTUSERTYPE");
						break;
					case USER_CR:
						myActivityIntent = new Intent(
								"com.example.projectqwerty001.ADDSUBJECTSACTIVITY");

						break;
					case USER_STUDENT:
						myActivityIntent = new Intent(
								"com.example.projectqwerty001.ADDSUBJECTSACTIVITY");
						break;
					}

					startActivity(myActivityIntent);
				}
			}

		};

		myThread.start();

	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

	void makeFullScreenActivity() {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}

	private void init() {
		// TODO Auto-generated method stub
		// Initializing Font
		initFonts();
		// Initializing TextView
		title = (TextView) findViewById(R.id.tvTitle);
		appVersion = (TextView) findViewById(R.id.tvAppVersion);
		userPref = getSharedPreferences(SHARED_PREFERENCES_FILENAME,
				MODE_PRIVATE);
		// locationManager = (LocationManager)
		// getSystemService(Context.LOCATION_SERVICE);

	}

	private void initFonts() {
		// TODO Auto-generated method stub
		robotoThin = Typeface.createFromAsset(getAssets(), "roboto-thin.ttf");
		robotoLight = Typeface.createFromAsset(getAssets(), "roboto-light.ttf");
	}
}