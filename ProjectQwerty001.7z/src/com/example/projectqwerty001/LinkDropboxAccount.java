//package com.example.projectqwerty001;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//public class LinkDropboxAccount extends Activity {
//
////	public DbxAccountManager mDbxAcctMgr;
//	Button link, next;
//	TextView tv;
//
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		// mDbxAcctMgr = DbxAccountManager.getInstance(getApplicationContext(),
//		// SplashActivity.DROPBOX_APP_KEY,
//		// SplashActivity.DROPBOX_APP_SECRET);
//		setContentView(R.layout.linkdropboxaccount);
//		init();
//
//	}
//
//	private void init() {
//		// TODO Auto-generated method stub
//		next = (Button) findViewById(R.id.bNextLinkDbxAcc);
//		next.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				Intent i = new Intent(
//						"com.example.projectqwerty001.ADDSUBJECTSACTIVITY");
//				startActivity(i);
//			}
//		});
//
//		link = (Button) findViewById(R.id.bLinkDropbox);
//		link.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
////				mDbxAcctMgr.startLink(LinkDropboxAccount.this, REQUEST_LINK_TO_DBX);
//			}
//		});
//
//		tv = (TextView) findViewById(R.id.tvLinkingStatus);
//
////		if (!mDbxAcctMgr.hasLinkedAccount()) {
//			next.setClickable(true);
//			tv.setText("Already Linked!");
//			link.setVisibility(Button.GONE);
//		}
//	}
//
//	@Override
//	protected void onPause() {
//		// TODO Auto-generated method stub
//		super.onPause();
//		// finish();
//	}
//
//	static final int REQUEST_LINK_TO_DBX = 0; // This value is up to you
//
//	// private void onClickLinkToDropbox() {
//	// mDbxAcctMgr.startLink((Activity) this, REQUEST_LINK_TO_DBX);
//	// }
//
//	@Override
//	public void onActivityResult(int requestCode, int resultCode, Intent data) {
//		if (requestCode == REQUEST_LINK_TO_DBX) {
//			if (resultCode == Activity.RESULT_OK) {
//				Toast.makeText(getApplicationContext(), "Successfully Linked",
//						Toast.LENGTH_SHORT).show();
//				next.setClickable(true);
//				tv.setText("Successfully Linked");
//				link.setVisibility(Button.GONE);
//
//				// Intent i = new Intent(
//				// "com.example.projectqwerty001.ADDSUBJECTSACTIVITY");
//				// startActivity(i);
//			} else {
//				// ... Link failed or was cancelled by the user.
//			}
//		} else {
//			super.onActivityResult(requestCode, resultCode, data);
//		}
//	}
//	
//	
//
//}
