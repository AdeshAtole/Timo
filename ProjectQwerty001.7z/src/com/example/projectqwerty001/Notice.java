package com.example.projectqwerty001;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Notice extends Activity implements OnClickListener {

	Button create, viewPrev;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notice);
		init();
	}

	private void init() {
		create = (Button) findViewById(R.id.bCreateNewNotice);
		create.setOnClickListener(this);

		viewPrev = (Button) findViewById(R.id.bViewPreviousNotice);
		viewPrev.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bCreateNewNotice:
			startActivity(new Intent(
					"com.example.projectqwerty001.CREATENEWNOTICE"));
			break;
		case R.id.bViewPreviousNotice:
			break;
		}
	}

}
