package com.example.projectqwerty001;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class HomeScreen extends Activity implements OnClickListener {

	int progressBarStatus = 0;
	ProgressBar pb;
	private Handler progressBarHandler = new Handler();
	private int duration = 0;
	long sec = 0;
	ImageButton ibTimeTable, ibNotice, ibLocation, ibManageSubjects;
	GestureDetector gestureDetector;
	LinearLayout llMenu;
	RelativeLayout rlMain;
	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
	Date d1, d2;
	TextView remaining;
	Handler mh = new Handler();
	int i;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_screen);
		init();

		final ProgressBar pb = (ProgressBar) findViewById(R.id.pbSubProgress);

		try {
			TimetableEntryInformation tti = TimeHandler.currentLecture(this);
			d1 = tti.getStartTime();
			d2 = tti.getEndTime();
		} catch (Exception e) {
			e.printStackTrace();
		}

		long millisDifference = d2.getTime() - d1.getTime();
		final long secDifference = millisDifference / 1000;

		pb.setMax((int) secDifference);
		pb.setProgress(0);
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				i = 0;

				Date d11 = null;
				try {
					d11 = sdf.parse(sdf.format(new Date()));
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				while ((d1.getTime() + d11.getTime()) != d2.getTime()) {

					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					i++;
					mh.post(new Runnable() {
						public void run() {
							// TODO Auto-generated method stub
							Date d = new Date();
							try {
								d = sdf.parse(sdf.format(d));
							} catch (ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							long sec = (d.getTime() - d1.getTime()) / 1000;
							pb.setProgress((int) sec);
							// pb.incrementProgressBy(1);
							setText(""
									+ (((secDifference - sec) / 60) + ":" + ((secDifference - sec) % 60))
									+ " mins remaining");
							Toast.makeText(getApplicationContext(),
									"IN MHPOST", Toast.LENGTH_SHORT).show();

						}
					});
				}

			}
		}).start();
	}

	private void setText(String s) {
		remaining.setText(s);

	}

	// TimetableEntryInformation ttInfo = TimeHandler.currentLecture(this);
	// Date startTime = ttInfo.getStartTime();
	// Date endTime = ttInfo.getEndTime();
	// long diff = endTime.getTime() - startTime.getTime();
	// sec = diff / 1000;
	// startProgressBar(sec);

	private void init() {
		pb = (ProgressBar) findViewById(R.id.pbSubProgress);

		remaining = (TextView) findViewById(R.id.tvRemaining);

		ibTimeTable = (ImageButton) findViewById(R.id.ibMenuTimeTable);
		ibTimeTable.setOnClickListener(this);

		// ibNotes = (ImageButton) findViewById(R.id.ibMenuNotes);
		// ibNotes.setOnClickListener(this);

		ibNotice = (ImageButton) findViewById(R.id.ibMenuNotice);
		ibNotice.setOnClickListener(this);

		ibLocation = (ImageButton) findViewById(R.id.ibMenuMaps);
		ibLocation.setOnClickListener(this);

		ibManageSubjects = (ImageButton) findViewById(R.id.ibMenuNotes);
		ibManageSubjects.setOnClickListener(this);

		gestureDetector = new GestureDetector(this.getApplicationContext(),
				new crmenuGestureDetector());

		llMenu = (LinearLayout) findViewById(R.id.llMenu_HomeScreen);

		rlMain = (RelativeLayout) findViewById(R.id.rlMain_HomeScreen);
		rlMain.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (gestureDetector.onTouchEvent(event)) {
					return true;
				}
				return false;
			}
		});
	}

	@SuppressWarnings("unused")
	private void startProgressBar(long max) {
		// TODO Auto-generated method stub
		pb.setProgress(0);
		pb.setMax((int) max);
		progressBarStatus = 0;
		duration = 0;
		// new Thread(new Runnable() {
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// while (progressBarStatus < 30) {
		// progressBarStatus = doTask();
		// try {
		// Thread.sleep(1000);
		// } catch (Exception e) {
		// e.printStackTrace();
		// }
		// progressBarHandler.post(new Runnable() {
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// pb.setProgress(progressBarStatus);
		// }
		// });
		// }
		// if (progressBarStatus >= 30) {
		// try {
		// Thread.sleep(2000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// // dismissDialog(id)
		// }
		// }
		// }).start();
	}

	public int doTask() {
		while (duration <= sec) {
			Date d = new Date();
			long mill = d.getTime();
			TimetableEntryInformation tt = new TimetableEntryInformation();
			tt = TimeHandler.currentLecture(this);
			duration = (int) ((mill - (tt.getEndTime().getTime())) / 1000);
			return duration;
		}
		return duration;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.ibMenuTimeTable:
			Toast.makeText(getApplicationContext(), "Time Table",
					Toast.LENGTH_SHORT).show();
			startActivity(new Intent(
					"com.example.projectqwerty001.NEWTIMETABLEENTRY"));
			break;
		case R.id.ibMenuNotice:
			startActivity(new Intent("com.example.projectqwerty001.NOTICE"));
			break;
		case R.id.ibMenuMaps:
			startActivity(new Intent(
					"com.example.projectqwerty001.SELECTPROFILEMANAGEMENTATTRIBUTES"));
			break;
		case R.id.ibMenuNotes:
			Toast.makeText(getApplicationContext(), "Manage Subjects",
					Toast.LENGTH_SHORT).show();
			startActivity(new Intent("com.example.projectqwerty001.SUBJECTLIST"));
			break;
		}
	}

	class crmenuGestureDetector extends SimpleOnGestureListener {

		private static final int SWIPE_MIN_DISTANCE = 100;
		private static final int SWIPE_MAX_OFF_PATH = 250;
		private static final int SWIPE_THRESHOLD_VELOCITY = 200;

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {

			if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH) {
				return false;
			}

			// right to left swipe
			if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
					&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {

				// llMenu.setLayoutParams(new LinearLayout.LayoutParams(
				// LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT,
				// 100.0f));
				llMenu.setVisibility(View.GONE);

			} // left to right swipe
			else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
					&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {

				llMenu.setVisibility(View.VISIBLE);
				// llMenu.setLayoutParams(new LinearLayout.LayoutParams(
				// LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
				// 82.0f));
			}

			return false;
		}

		// It is necessary to return true from onDown for the onFling event to
		// register
		@Override
		public boolean onDown(MotionEvent e) {
			return true;
		}

	}
}
