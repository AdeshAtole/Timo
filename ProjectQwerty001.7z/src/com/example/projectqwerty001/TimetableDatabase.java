package com.example.projectqwerty001;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class TimetableDatabase {
	public static final String KEY_START_TIME = "START_TIME";
	public static final String KEY_END_TIME = "END_TIME";
	public static final String KEY_SUBJECT_NAME = "SUBJECT_NAME";

	public static final String DATABASE_NAME = "DATABASE_NAME_TIME_TABLE";
	public static final int DATABASE_VERSION = 1;

	public static final String TABLE_NAME_TIME_TABLE_SUN = "TIME_TABLE_TABLE_SUN";
	public static final String TABLE_NAME_TIME_TABLE_MON = "TIME_TABLE_TABLE_MON";
	public static final String TABLE_NAME_TIME_TABLE_TUE = "TIME_TABLE_TABLE_TUE";
	public static final String TABLE_NAME_TIME_TABLE_WED = "TIME_TABLE_TABLE_WED";
	public static final String TABLE_NAME_TIME_TABLE_THU = "TIME_TABLE_TABLE_THU";
	public static final String TABLE_NAME_TIME_TABLE_FRI = "TIME_TABLE_TABLE_FRI";
	public static final String TABLE_NAME_TIME_TABLE_SAT = "TIME_TABLE_TABLE_SAT";

	public static final int SUN = 1;
	public static final int MON = 2;
	public static final int TUE = 3;
	public static final int WED = 4;
	public static final int THU = 5;
	public static final int FRI = 6;
	public static final int SAT = 7;

	SimpleDateFormat parseFormat = new SimpleDateFormat("HH:mm");
	SimpleDateFormat displayFromat = new SimpleDateFormat("hh:mm a");

	private DbHelper ourHelper;
	private Context ourContext;
	private SQLiteDatabase ourDatabase;

	public TimetableDatabase(Context c) throws SQLException {
		ourContext = c;
	}

	public TimetableDatabase open() throws SQLException {
		ourHelper = new DbHelper(ourContext);
		ourDatabase = ourHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		ourHelper.close();
	}

	public long createEntry(String TableName, Date startTime, Date endTime,
			String subjectName) throws SQLiteConstraintException, SQLException {
		String sStartTime = parseFormat.format(startTime);
		String sEndTime = parseFormat.format(endTime);

		ContentValues cv = new ContentValues();
		cv.put(KEY_SUBJECT_NAME, subjectName);
		cv.put(KEY_START_TIME, sStartTime);
		cv.put(KEY_END_TIME, sEndTime);
		return ourDatabase.insert(TableName, null, cv);
	}

	public ArrayList<TimetableEntryInformation> getSubjects(String tableName)
			throws SQLiteException, ParseException {
		ArrayList<TimetableEntryInformation> subjectInformationList = new ArrayList<TimetableEntryInformation>();
		String columns[] = new String[] { KEY_START_TIME, KEY_END_TIME,
				KEY_SUBJECT_NAME };
		Cursor c = ourDatabase.query(tableName, columns, null, null, null,
				null, KEY_START_TIME + " ASC");

		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			TimetableEntryInformation tei = new TimetableEntryInformation();
			tei.setEntry(parseFormat.parse(c.getString(c
					.getColumnIndex(KEY_START_TIME))), parseFormat.parse(c
					.getString(c.getColumnIndex(KEY_END_TIME))), c.getString(c
					.getColumnIndex(KEY_SUBJECT_NAME)));
			subjectInformationList.add(tei);
		}
		return subjectInformationList;
	}

	public long getNumberOfEntries(String tableName) {
		// STUB
		long numRows = DatabaseUtils.longForQuery(ourDatabase,
				"SELECT COUNT(*) FROM " + tableName, null);
		return numRows;
	}

	public static String getTableName(int day) {
		switch (day) {
		case SUN:
			return TABLE_NAME_TIME_TABLE_SUN;
		case MON:
			return TABLE_NAME_TIME_TABLE_MON;
		case TUE:
			return TABLE_NAME_TIME_TABLE_TUE;
		case WED:
			return TABLE_NAME_TIME_TABLE_WED;
		case THU:
			return TABLE_NAME_TIME_TABLE_THU;
		case FRI:
			return TABLE_NAME_TIME_TABLE_FRI;
		case SAT:
			return TABLE_NAME_TIME_TABLE_SAT;
		}
		return null;
	}

	public ArrayList<TimeRange> getTimeRanges(String tableName)
			throws ParseException {
		ArrayList<TimeRange> timeRangeList = new ArrayList<TimeRange>();
		String columns[] = new String[] { KEY_START_TIME, KEY_END_TIME,
				KEY_SUBJECT_NAME };
		Cursor c = ourDatabase.query(tableName, columns, null, null, null,
				null, KEY_START_TIME + " ASC");

		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {

			TimeRange tr = new TimeRange(parseFormat.parse(c.getString(c
					.getColumnIndex(KEY_START_TIME))), parseFormat.parse(c
					.getString(c.getColumnIndex(KEY_END_TIME))));
			timeRangeList.add(tr);
		}
		return timeRangeList;
	}

	public ArrayList<TimeRange> getExcludedTimeRanges(String tableName,
			Date startTime) throws ParseException {
		ArrayList<TimeRange> timeRangeList = new ArrayList<TimeRange>();
		String columns[] = new String[] { KEY_START_TIME, KEY_END_TIME,
				KEY_SUBJECT_NAME };
		Cursor c = ourDatabase.query(tableName, columns, KEY_START_TIME + "!="
				+ "\"" + parseFormat.format(startTime) + "\"", null, null,
				null, KEY_START_TIME + " ASC");

		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {

			TimeRange tr = new TimeRange(parseFormat.parse(c.getString(c
					.getColumnIndex(KEY_START_TIME))), parseFormat.parse(c
					.getString(c.getColumnIndex(KEY_END_TIME))));
			timeRangeList.add(tr);
		}
		return timeRangeList;
	}

	public boolean removeTimetableEntry(String tableName, Date startTime) {
		String sStartTime = parseFormat.format(startTime);
		ourDatabase.delete(tableName, KEY_START_TIME + "=" + "\"" + sStartTime
				+ "\"", null);
		return true;
	}

	public void updateTimetableEntry(String tableName, Date oldStartTime,
			Date newStartTime, Date newEndTime, String newSubjectName) {
		ContentValues cv = new ContentValues();
		cv.put(KEY_SUBJECT_NAME, newSubjectName);
		cv.put(KEY_START_TIME, parseFormat.format(newStartTime));
		cv.put(KEY_END_TIME, parseFormat.format(newEndTime));
		ourDatabase.update(tableName, cv, KEY_START_TIME + "=" + "\""
				+ parseFormat.format(oldStartTime) + "\"", null);
	}

	private static class DbHelper extends SQLiteOpenHelper {

		DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_SUN + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_MON + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_TUE + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_WED + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_THU + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_FRI + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			db.execSQL("CREATE TABLE " + TABLE_NAME_TIME_TABLE_SAT + " ("
					+ KEY_START_TIME + " TEXT UNIQUE" + "," + KEY_END_TIME
					+ " TEXT UNIQUE" + "," + KEY_SUBJECT_NAME + " TEXT" + ");");
			// dummy stuff for creating the log for testing
			String dummyQuery = "CREATE TABLE " + TABLE_NAME_TIME_TABLE_SUN
					+ " (" + KEY_START_TIME + " DATETIME" + "," + KEY_END_TIME
					+ " DATETIME" + KEY_SUBJECT_NAME + " TEXT" + ");";
			Log.d("DUMMY_Q", dummyQuery);
			// DUMMY STUFF ENDS
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			try {
				db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_TIME_TABLE_MON
						+ ";");
				onCreate(db);
				Log.d("DB_SUCCESS", "Query Success");
			} catch (SQLException e) {
				// TODO: handle exception
				Log.d("DB_FAILURE", "Query Error");
			}
		}

	}

}