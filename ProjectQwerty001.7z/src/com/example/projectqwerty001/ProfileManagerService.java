package com.example.projectqwerty001;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Toast;

public class ProfileManagerService extends Service {
	AudioManager am;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		SharedPreferences prefs = getSharedPreferences(
				SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
		boolean b = prefs.getBoolean(SplashActivity.KEY_FLAG_TIME_BASED, false);
		if (b) {
			am = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);

			if (TimeHandler.currentLecture(this) != null) {
				if (am.getRingerMode() != AudioManager.RINGER_MODE_VIBRATE) {
					am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
					Toast.makeText(getApplicationContext(),
							"Ringer Mode Set to Vibrate", Toast.LENGTH_LONG)
							.show();
				}
			} else {
				if (am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) {
					am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
					Toast.makeText(getApplicationContext(),
							"Ringer Mode Set to Normal", Toast.LENGTH_LONG)
							.show();
				}
			}
		}
		return START_STICKY;
	}
}