package com.example.projectqwerty001;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SetRadius extends Activity {

	EditText radius;
	Button set;

	public static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATE = 1;
	public static final long MINIMUM_TIME_BETWEEN_UPDATE = 5 * 1000;
	public static final long PROXIMITY_ALERT_EXPIRATION = -1;
	public static final String PROX_ALERT_INTENT = "com.example.projectqwerty001.ProximityAlert";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.set_radius);
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		set = (Button) findViewById(R.id.bSet_setRadius);
		set.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String r = radius.getText().toString();
				if (Integer.parseInt(r) < 100) {
					Toast.makeText(getApplicationContext(),
							"Minimum radius is 100 meters", Toast.LENGTH_SHORT)
							.show();
					return;
				}
				SharedPreferences prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				if (prefs.getBoolean(SplashActivity.KEY_SETUP_COMPLETED, false) == true) {
					SelectProfileManagementAttributes.getInstance().finish();
					SelectLocation.getInstance().finish();
					finish();
					return;
				}
				Editor editor = prefs.edit();
				editor.putLong(SplashActivity.KEY_PROXIMITY_RADIUS,
						Long.parseLong(r));
				editor.commit();

				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				editor = prefs.edit();
				editor.putBoolean(SplashActivity.KEY_SETUP_COMPLETED, true);
				editor.commit();

				// setProximityAlert();

				if (prefs.getBoolean(SplashActivity.KEY_SETUP_COMPLETED, false) == false)
					startActivity(new Intent(
							"com.example.projectqwerty001.SETUPCOMPLETED"));

				Intent i = new Intent(SetRadius.this, ProximityService.class);
				PendingIntent pi = PendingIntent.getService(SetRadius.this,
						012, i, 0);
				AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
				alarm.setRepeating(AlarmManager.RTC_WAKEUP, Calendar
						.getInstance().getTimeInMillis(), 5 * 1000, pi);
				Toast.makeText(getApplicationContext(),
						"Profile Management Service Started",
						Toast.LENGTH_SHORT).show();
				startActivity(new Intent(
						"com.example.projectqwerty001.SETUPCOMPLETED"));
				SelectProfileManagementAttributes.getInstance().finish();
				SelectLocation.getInstance().finish();
				finish();
			}

		});

		radius = (EditText) findViewById(R.id.etRadius);
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

	// private void setProximityAlert() {
	// // TODO Auto-generated method stub
	// SharedPreferences pref = getSharedPreferences(
	// SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
	// double lat = pref.getLong(SplashActivity.KEY_LATITUDE, 0);
	// double lon = pref.getLong(SplashActivity.KEY_LONGITUDE, 0);
	// long radius = pref.getLong(SplashActivity.KEY_PROXIMITY_RADIUS, 0);
	// addProximityAlert(this, lat, lon, (int) radius);
	// }

	// private void addProximityAlert(Context c, double latitude,
	// double longitude, int radius) {
	// Intent intent = new Intent(PROX_ALERT_INTENT);
	// PendingIntent proximityIntent = PendingIntent.getBroadcast(c, 0,
	// intent, 0);
	// SplashActivity.locationManager.addProximityAlert(latitude, longitude,
	// radius, PROXIMITY_ALERT_EXPIRATION, proximityIntent);
	// IntentFilter filter = new IntentFilter(PROX_ALERT_INTENT);
	// registerReceiver(new ProximityIntentReceiver(), filter);
	// // PendingIntent proximityIntent = PendingIntent.getBroadcast(this, 0,
	// // intent, 0);
	// // locationManager.addProximityAlert(latitude, longitude,
	// // RADIUS/* in meters */, PROXIMITY_ALERT_EXPIRATION,
	// // proximityIntent);
	// // IntentFilter filter = new IntentFilter(INTENT_PROX_ALERT);
	// // registerReceiver(new ProximityIntentReceiver(), filter);
	// // INCOMPLETE
	// }

}