package com.example.projectqwerty001;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class CreateTimeTable extends Activity implements OnItemSelectedListener {

	Spinner spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.createtimetable);
		init();
		String subjectList[] = getIntent().getExtras().getStringArray(
				SplashActivity.KEY_SUBJECT_LIST);
		ArrayAdapter<String> subjectAdapter = new ArrayAdapter<String>(
				CreateTimeTable.this, android.R.layout.simple_spinner_item,
				subjectList);
		spinner.setAdapter(subjectAdapter);
		spinner.setOnItemSelectedListener(this);
	}

	private void init() {
		// TODO Auto-generated method stub
		spinner = (Spinner) findViewById(R.id.spinner1);
	}

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub

		Toast.makeText(getApplicationContext(),
				"" + (String) spinner.getSelectedItem(), Toast.LENGTH_LONG)
				.show();

	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
