package com.example.projectqwerty001;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

@SuppressLint("SimpleDateFormat")
public class NewTimetableEntry extends Activity implements OnClickListener {
	ListView lvSubjectListView;
	LinearLayout llTapToAdd;
	Button daysButtons[] = new Button[7];
	Button add, next;

	SimpleDateFormat parseFormat = new SimpleDateFormat("HH:mm");
	SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a");

	public static int currentlyOpenedDay = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_timetable_entry);
		init();
		handleVisibility();
		// Weather weather_data[] = new Weather[] {
		// new Weather("10:00", "11:00", "ABC"),
		// new Weather("11:00", "12:00", "DEF"),
		// new Weather("12:00", "01:00", "GHI") };

		// WeatherAdapter adapter = new WeatherAdapter(this,
		// R.layout.listview_item_row, weather_data);

		// View header = (View) getLayoutInflater().inflate(
		// R.layout.listview_header_row, null);

		// lvSubjectListView.addHeaderView(header);
		// lvSubjectListView.setAdapter(adapter);

		// // dummy starts
		// TimetableDatabase tt = new TimetableDatabase(this);
		// tt.open();
		// tt.createEntry(tt.TABLE_NAME_TIME_TABLE_SUN, "00;00", "01:11",
		// "qwer");
		// long x = tt.createEntry(TimetableDatabase.TABLE_NAME_TIME_TABLE_SUN,
		// "10:00", "12:00", "MySub");
		// tt.close();
		//
		// tt.open();
		// // long y = 0;
		// long y = tt.createEntry(TimetableDatabase.TABLE_NAME_TIME_TABLE_SUN,
		// "04:00", "05:00", "AI");
		// tt.close();
		//
		// Toast.makeText(getApplicationContext(), "X= " + x + "  y=" + y,
		// Toast.LENGTH_SHORT).show();
		//
		// tt.open();
		// ArrayList<TimetableEntryInformation> subList = tt
		// .getSubjects(TimetableDatabase.TABLE_NAME_TIME_TABLE_SUN);
		// tt.close();
		//
		// TextView tvDummy = (TextView) findViewById(R.id.tvDummy);
		// tvDummy.setText("");
		// String contList = "";
		// for (int i = 0; i < subList.size(); i++) {
		// TimetableEntryInformation tttt = subList.get(i);
		// // contList = tttt.getStartTime() + " " + tttt.getEndTime() + " "
		// // + tttt.getSubjectName();
		// contList = contList + tttt.getSubjectName() + " "
		// + tttt.getStartTime() + " " + tttt.getEndTime() + "\n";
		// // tvDummy.append(contList);
		// // Toast.makeText(getApplicationContext(), tttt.getSubjectName(),
		// // Toast.LENGTH_SHORT).show();
		// }
		//
		// // Toast.makeText(getApplicationContext(), text, duration)
		//
		// tvDummy.setText(contList);
		// TimetableDatabase qw = new TimetableDatabase(this);
		// qw.open();
		// long a = qw
		// .getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_SUN);
		// qw.close();
		// Toast.makeText(getApplicationContext(), "" + a, Toast.LENGTH_LONG)
		// .show();
		// // dummy ends
		try {
			Toast.makeText(getApplicationContext(),
					TimeHandler.currentLecture(this).getSubjectName(),
					Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void handleVisibility() {
		// TODO Auto-generated method stub
		SharedPreferences prefs = getSharedPreferences(
				SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
		boolean setupStatus = prefs.getBoolean(
				SplashActivity.KEY_SETUP_COMPLETED, false);
		if (setupStatus == true) {
			next.setVisibility(Button.GONE);
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		daysButtons[currentlyOpenedDay - 1].performClick();
	}

	private void init() {
		// TODO Auto-generated method stub
		lvSubjectListView = (ListView) findViewById(R.id.lvListOfSubjects_TT);
		lvSubjectListView
				.setOnItemClickListener(new ListView.OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View v,
							int position, long id) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "in listener",
								Toast.LENGTH_LONG).show();
						TimetableEntryInformation ttInfo = new TimetableEntryInformation();
						// ttInfo = (TimetableEntryInformation)
						// lvSubjectListView
						// .getSelectedItem();

						ArrayList<TimetableEntryInformation> ttInfoList = new ArrayList<TimetableEntryInformation>();
						TimetableDatabase ttdb = new TimetableDatabase(
								NewTimetableEntry.this);
						ttdb.open();
						try {
							ttInfoList = ttdb.getSubjects(TimetableDatabase
									.getTableName(currentlyOpenedDay));
						} catch (SQLiteException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						ttdb.close();

						ttInfo = ttInfoList.get(position);

						if (ttInfo == null) {
							Toast.makeText(getApplicationContext(), "NULL",
									Toast.LENGTH_SHORT).show();
							return;
						} else {
							Toast.makeText(getApplicationContext(), "NOT NULL",
									Toast.LENGTH_SHORT).show();
						}
						Bundle b = new Bundle();
						b.putString(
								SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_SUBJECT_NAME,
								ttInfo.getSubjectName());
						b.putString(
								SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME,
								parseFormat.format(ttInfo.getStartTime()));
						b.putString(
								SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_ENDTIME,
								parseFormat.format(ttInfo.getEndTime()));

						Intent i = new Intent(NewTimetableEntry.this,
								EditTimeTableEntry.class);
						i.putExtras(b);
						startActivity(i);
					}

				});

		daysButtons[0] = (Button) findViewById(R.id.bTTSun);
		daysButtons[1] = (Button) findViewById(R.id.bTTMon);
		daysButtons[2] = (Button) findViewById(R.id.bTTTue);
		daysButtons[3] = (Button) findViewById(R.id.bTTWed);
		daysButtons[4] = (Button) findViewById(R.id.bTTThu);
		daysButtons[5] = (Button) findViewById(R.id.bTTFri);
		daysButtons[6] = (Button) findViewById(R.id.bTTSat);

		add = (Button) findViewById(R.id.bAddNewSubject_newTTEntry);
		add.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Add",
						Toast.LENGTH_SHORT).show();
				Intent i = new Intent(
						"com.example.projectqwerty001.ADDNEWTIMETABLEENTRY");
				startActivity(i);
			}
		});

		next = (Button) findViewById(R.id.bNext_newTTEntry);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(
						"com.example.projectqwerty001.SELECTPROFILEMANAGEMENTATTRIBUTES");
				startActivity(i);
				SubjectList.getInstance().finish();
				finish();
			}
		});

		for (int i = 0; i < daysButtons.length; i++) {
			daysButtons[i].setOnClickListener(this);
		}
		llTapToAdd = (LinearLayout) findViewById(R.id.llTapToAdd_TT);
		llTapToAdd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Tapped",
						Toast.LENGTH_SHORT).show();
				Intent i = new Intent(
						"com.example.projectqwerty001.ADDNEWTIMETABLEENTRY");
				startActivity(i);
			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		for (int i = 0; i < daysButtons.length; i++) {
			if (v.getId() == daysButtons[i].getId()) {
				daysButtons[i].setBackgroundColor(Color.rgb(00, 150, 222));
			} else {
				daysButtons[i]
						.setBackgroundResource(R.drawable.time_table_days_button);
			}
		}

		TimetableDatabase ttDb = new TimetableDatabase(this);

		switch (v.getId()) {
		case R.id.bTTSun:
			long entries;
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_SUN);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				add.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				add.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}

			currentlyOpenedDay = TimetableDatabase.SUN;
			break;
		case R.id.bTTMon:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_MON);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.MON;
			break;
		case R.id.bTTTue:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_TUE);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.TUE;
			break;

		case R.id.bTTWed:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_WED);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.WED;
			break;
		case R.id.bTTThu:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_THU);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.THU;
			break;
		case R.id.bTTFri:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_FRI);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.FRI;
			break;
		case R.id.bTTSat:
			ttDb.open();
			entries = ttDb
					.getNumberOfEntries(TimetableDatabase.TABLE_NAME_TIME_TABLE_SAT);
			ttDb.close();

			if (entries == 0) {
				lvSubjectListView.setVisibility(View.GONE);
				llTapToAdd.setVisibility(View.VISIBLE);
			} else {
				lvSubjectListView.setVisibility(View.VISIBLE);
				llTapToAdd.setVisibility(View.GONE);
			}
			currentlyOpenedDay = TimetableDatabase.SAT;
			break;
		}

		// START
		ArrayList<TimetableEntryInformation> ttInfoList = new ArrayList<TimetableEntryInformation>();
		TimetableDatabase ttdb = new TimetableDatabase(this);
		ttdb.open();
		try {
			ttInfoList = ttdb.getSubjects(TimetableDatabase
					.getTableName(currentlyOpenedDay));
		} catch (SQLiteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Weather weather_data[] = new Weather[ttInfoList.size()];
		for (int i = 0; i < ttInfoList.size(); i++) {
			TimetableEntryInformation ttInfo = new TimetableEntryInformation();
			ttInfo = ttInfoList.get(i);
			weather_data[i] = new Weather(displayFormat.format(ttInfo
					.getStartTime()),
					displayFormat.format(ttInfo.getEndTime()),
					ttInfo.getSubjectName());
		}
		ttdb.close();
		WeatherAdapter adapter = new WeatherAdapter(this,
				R.layout.listview_item_row, weather_data);
		lvSubjectListView.setAdapter(adapter);
		// END
	}
}
