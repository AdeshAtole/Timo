package com.example.projectqwerty001;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

@SuppressLint("SimpleDateFormat")
public class EditTimeTableEntry extends Activity implements OnClickListener,
		OnItemSelectedListener {

	Button changeStartTime, changeEndTime, save, remove;
	TextView startTime, endTime;
	Spinner selectSubject;

	public static final int ID_DIALOG_START_TIME = 0;
	public static final int ID_DIALOG_END_TIME = 1;

	ApplicationDatabase adb;

	SimpleDateFormat parseFormat = new SimpleDateFormat("HH:mm");
	SimpleDateFormat displayFormat = new SimpleDateFormat("hh:mm a");
	SimpleDateFormat hrFormat = new SimpleDateFormat("HH");
	SimpleDateFormat minFormat = new SimpleDateFormat("mm");
	// SimpleDateFormat aFormat = new SimpleDateFormat("a");

	Date dStartTime = null, dEndTime = null;
	Bundle b;

	int startHr, startMin, endHr, endMin;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Log.d("MYTAG", "In ETTE");
		setContentView(R.layout.add_new_timetable_entry);
		Log.d("MYTAG", "content View");
		init();

		Log.d("MYTAG", "init() completed");

		ArrayList<String> subjectNameArrayList = new ArrayList<String>();

		adb = new ApplicationDatabase(this);
		adb.open();
		subjectNameArrayList = adb.getSubjects();
		adb.close();

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(
				EditTimeTableEntry.this, android.R.layout.simple_spinner_item,
				subjectNameArrayList);
		selectSubject.setAdapter(adapter);

		b = getIntent().getExtras();
		setValues(b);
	}

	private void setValues(Bundle b) {
		// TODO Auto-generated method stub
		String subjectName = b
				.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_SUBJECT_NAME);
		Date dStartTime1 = null, dEndTime1 = null;
		try {
			dStartTime1 = parseFormat
					.parse(b.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME));
			dEndTime1 = parseFormat
					.parse(b.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_ENDTIME));

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Now setting the spinner to the proper subject name
		ArrayList<String> subjectNameArrayList = new ArrayList<String>();
		adb.open();
		subjectNameArrayList = adb.getSubjects();
		adb.close();
		selectSubject.setSelection(subjectNameArrayList.indexOf(subjectName));

		// Now setting startTime textView
		String sStartTime = displayFormat.format(dStartTime1);
		this.startTime.setText(sStartTime);

		// Now setting endTime TextView
		String sEndTime = displayFormat.format(dEndTime1);
		this.endTime.setText(sEndTime);

		// Now setting Default values for start time picker dialog
		startHr = Integer.parseInt(hrFormat.format(dStartTime1));
		startMin = Integer.parseInt(minFormat.format(dStartTime1));

		// Now setting default values for end time picker dialog
		endHr = Integer.parseInt(hrFormat.format(dEndTime1));
		endMin = Integer.parseInt(minFormat.format(dEndTime1));

		dStartTime = dStartTime1;
		dEndTime = dEndTime1;
	}

	public void init() {
		changeStartTime = (Button) findViewById(R.id.bSetStartTime);
		changeStartTime.setOnClickListener(this);
		changeStartTime.setText("Change");

		Log.d("MYTAG", "starTime Button");

		changeEndTime = (Button) findViewById(R.id.bSetEndTime);
		changeEndTime.setOnClickListener(this);
		changeEndTime.setText("Change");

		selectSubject = (Spinner) findViewById(R.id.spSelectSubject);
		selectSubject.setOnItemSelectedListener(this);

		save = (Button) findViewById(R.id.bSave_newTTEntry);
		save.setOnClickListener(this);
		Log.d("MYTAG", "save button");
		startTime = (TextView) findViewById(R.id.tvStartTime_newTTEntry);
		Log.d("MYTAG", "tv1");
		endTime = (TextView) findViewById(R.id.tvEndTime_newTTEntry);
		Log.d("MYTAG", "tv2");

		remove = (Button) findViewById(R.id.bRemoveTTEntry);
		remove.setOnClickListener(this);
		remove.setVisibility(Button.VISIBLE);
	}

	@SuppressWarnings("unused")
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bSetStartTime:
			showDialog(ID_DIALOG_START_TIME);
			break;
		case R.id.bSetEndTime:
			showDialog(ID_DIALOG_END_TIME);
			break;
		case R.id.bSave_newTTEntry:
			// This one's final for the Save Button
			String n = (String) selectSubject.getSelectedItem();
			Toast.makeText(getApplicationContext(), n, Toast.LENGTH_SHORT)
					.show();
			// String a = TimeHandler.convertTo24Hr("01:30 am");
			// Toast.makeText(getApplicationContext(), a, Toast.LENGTH_LONG)
			// .show();

			String subjectName = (String) selectSubject.getSelectedItem();
			// String sStartTime = TimeHandler.convertTo24Hr(startTime.getText()
			// .toString());
			// String sEndTime = TimeHandler.convertTo24Hr(endTime.getText()
			// .toString());

			if (dStartTime == null) {
				Toast.makeText(getApplicationContext(),
						"Enter a proper Start Time", Toast.LENGTH_SHORT).show();
				break;
			}

			if (dEndTime == null) {
				Toast.makeText(getApplicationContext(),
						"Enter a proper End Time", Toast.LENGTH_SHORT).show();
			}

			if (dStartTime.equals(dEndTime)) {
				Toast.makeText(getApplicationContext(),
						"Start and End times are same!", Toast.LENGTH_SHORT)
						.show();
				break;
			}

			if (dStartTime.after(dEndTime)) {
				Toast.makeText(getApplicationContext(),
						"End time is before Start time", Toast.LENGTH_SHORT)
						.show();
				break;

			}

			// int compareResult = sStartTime.compareTo(sEndTime);
			// if (compareResult > 0) {
			// Toast.makeText(getApplicationContext(),
			// "End time is before Start time", Toast.LENGTH_SHORT)
			// .show();
			// break;
			// }
			// Toast.makeText(getApplicationContext(),
			// sStartTime + "  " + sEndTime, Toast.LENGTH_SHORT).show();

			TimeRange currentTimeRange = new TimeRange(dStartTime, dEndTime);

			ArrayList<TimeRange> trList = new ArrayList<TimeRange>();

			TimetableDatabase ttdb1 = new TimetableDatabase(this);
			ttdb1.open();
			try {
				trList = ttdb1.getExcludedTimeRanges(TimetableDatabase
						.getTableName(NewTimetableEntry.currentlyOpenedDay),
						dStartTime);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ttdb1.close();

			boolean res = true;

			for (int i = 0; i < trList.size(); i++) {
				boolean result = TimeHandler.isConflict(currentTimeRange,
						trList.get(i));
				if (result == true) {
					Toast.makeText(getApplicationContext(),
							"Time Ranges Overlap", Toast.LENGTH_SHORT).show();
					res = false;
					break;
				}
			}

			if (res == false) {
				break;
			}

			// finally, after all checks, adding the stuff to database. huh,
			// SIGHS!
			TimetableDatabase ttdb = new TimetableDatabase(this);
			ttdb.open();
			try {
				// ttdb.updateTimetableEntry(
				// TimetableDatabase
				// .getTableName(NewTimetableEntry.currentlyOpenedDay),
				// parseFormat.parse(b
				// .getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME)),
				// parseFormat.parse(this.startTime.getText().toString()),
				// parseFormat.parse(this.endTime.getText().toString()),
				// (String) selectSubject.getSelectedItem());
				ttdb.updateTimetableEntry(
						TimetableDatabase
								.getTableName(NewTimetableEntry.currentlyOpenedDay),
						parseFormat.parse(b
								.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME)),
						dStartTime, dEndTime, (String) selectSubject
								.getSelectedItem());
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				ttdb.close();
			}

			// try {
			// ttdb.open();
			// long result = ttdb.createEntry(TimetableDatabase
			// .getTableName(NewTimetableEntry.currentlyOpenedDay),
			// dStartTime, dEndTime, (String) selectSubject
			// .getSelectedItem());
			// ttdb.close();
			// if (result == -1) {
			// Toast.makeText(getApplicationContext(),
			// "Another Subject Starts OR Ends at Same Time",
			// Toast.LENGTH_SHORT).show();
			// break;
			// }
			// } catch (SQLiteConstraintException e) {
			// Toast.makeText(getApplicationContext(),
			// "Another Subject Starts OR Ends at Same Time",
			// Toast.LENGTH_SHORT).show();
			// break;
			// } catch (SQLException se) {
			// Toast.makeText(getApplicationContext(),
			// "Something went Wrong : " + se, Toast.LENGTH_LONG)
			// .show();
			// }
			finish();
			break;
		case R.id.bRemoveTTEntry:
			// TODO Auto-generated method stub
			TimetableDatabase ttdb2 = new TimetableDatabase(
					EditTimeTableEntry.this);
			ttdb2.open();
			try {
				ttdb2.removeTimetableEntry(
						TimetableDatabase
								.getTableName(NewTimetableEntry.currentlyOpenedDay),
						parseFormat.parse(b
								.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_STARTTIME)));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ttdb2.close();
			Toast.makeText(
					getApplicationContext(),
					b.getString(SplashActivity.KEY_ACTIVITY_TIMETABLE_ENTRY_INFO_SUBJECT_NAME)
							+ " removed", Toast.LENGTH_SHORT).show();
			finish();
			break;
		}
	}

	@Override
	protected Dialog onCreateDialog(int id, Bundle args) {
		// TODO Auto-generated method stub
		switch (id) {
		case ID_DIALOG_START_TIME:
			return new TimePickerDialog(this, startTimeSetListener, startHr,
					startMin, false);
		case ID_DIALOG_END_TIME:
			return new TimePickerDialog(this, endTimeSetListener, endHr,
					endMin, false);
		}
		return super.onCreateDialog(id, args);
	}

	private OnTimeSetListener startTimeSetListener = new OnTimeSetListener() {

		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			// TODO Auto-generated method stub
			String sHourOfDay = String.valueOf(hourOfDay);
			if (sHourOfDay.length() == 1) {
				sHourOfDay = "0" + sHourOfDay;
			}

			String sMinute = String.valueOf(minute);
			if (sMinute.length() == 1) {
				sMinute = "0" + sMinute;
			}

			String time = sHourOfDay + ":" + sMinute;

			try {
				dStartTime = parseFormat.parse(time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			startTime.setText(displayFormat.format(dStartTime));
			// //
			// String ampm = "am";
			// if (hourOfDay >= 12) {
			// hourOfDay = hourOfDay - 12;
			// ampm = "pm";
			// }
			//
			// String sHourOfDay = String.valueOf(hourOfDay);
			// if (sHourOfDay.length() == 1) {
			// sHourOfDay = "0" + sHourOfDay;
			// }
			//
			// String sMinute = String.valueOf(minute);
			// if (sMinute.length() == 1) {
			// sMinute = "0" + sMinute;
			// }
			//
			// startTime.setText("" + sHourOfDay + ":" + sMinute + " " + ampm);

			changeStartTime.setText("Change");

			Toast.makeText(getApplicationContext(),
					displayFormat.format(dStartTime), Toast.LENGTH_LONG).show();

		}
	};

	private OnTimeSetListener endTimeSetListener = new OnTimeSetListener() {

		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			// TODO Auto-generated method stub

			String sHourOfDay = String.valueOf(hourOfDay);
			if (sHourOfDay.length() == 1) {
				sHourOfDay = "0" + sHourOfDay;
			}

			String sMinute = String.valueOf(minute);
			if (sMinute.length() == 1) {
				sMinute = "0" + sMinute;
			}

			String time = sHourOfDay + ":" + sMinute;

			try {
				dEndTime = parseFormat.parse(time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// String ampm = "am";
			// if (hourOfDay >= 12) {
			// hourOfDay = hourOfDay - 12;
			// ampm = "pm";
			// }

			// String sHourOfDay = String.valueOf(hourOfDay);
			// if (sHourOfDay.length() == 1) {
			// sHourOfDay = "0" + sHourOfDay;
			// }
			//
			// String sMinute = String.valueOf(minute);
			// if (sMinute.length() == 1) {
			// sMinute = "0" + sMinute;
			// }

			endTime.setText(displayFormat.format(dEndTime));

			changeEndTime.setText("Change");

			Toast.makeText(getApplicationContext(),
					displayFormat.format(dEndTime), Toast.LENGTH_LONG).show();

		}
	};

	@SuppressWarnings("unused")
	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
			long arg3) {
		// TODO Auto-generated method stub
		adb.open();
		String subName = adb.getSubjectName(position);
		adb.close();
		// Toast.makeText(getApplicationContext(), subName, Toast.LENGTH_SHORT)
		// .show();
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
