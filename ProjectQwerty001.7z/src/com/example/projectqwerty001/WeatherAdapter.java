package com.example.projectqwerty001;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class WeatherAdapter extends ArrayAdapter<Weather> {

	Context context;
	int layoutResourceId;
	Weather data[] = null;

	public WeatherAdapter(Context context, int layoutResourceId, Weather[] data) {
		super(context, layoutResourceId, data);
		// TODO Auto-generated constructor stub
		this.context = context;
		this.data = data;
		this.layoutResourceId = layoutResourceId;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View row = convertView;
		WeatherHolder holder = null;
		if (row == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			row = inflater.inflate(layoutResourceId, parent, false);
			holder = new WeatherHolder();
			holder.startTime = (TextView) row.findViewById(R.id.tvStartTime);
			holder.endTime = (TextView) row.findViewById(R.id.tvEndTime);
			holder.subjectName = (TextView) row
					.findViewById(R.id.tvSubjectName);
			row.setTag(holder);
		} else {
			holder = (WeatherHolder) row.getTag();
		}

		Weather weather = data[position];

		holder.startTime.setText(weather.startTime);
		holder.endTime.setText(weather.endTime);
		holder.subjectName.setText(weather.subjectName);
		return row;
	}

	static class WeatherHolder {
		TextView startTime, endTime, subjectName;
	}
}
