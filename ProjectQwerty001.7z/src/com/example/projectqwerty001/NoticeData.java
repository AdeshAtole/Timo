package com.example.projectqwerty001;

import java.io.Serializable;

public class NoticeData implements Serializable {
	private String subject = null;
	private String body = null;

	NoticeData(String subject, String body) {
		this.subject = subject;
		this.body = body;
	}

	public String getSubject() {
		return subject;
	}

	public String getBody() {
		return body;
	}
}
