package com.example.projectqwerty001;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Toast;

public class SelectProfileManagementAttributes extends Activity implements
		OnCheckedChangeListener, OnClickListener {

	CheckBox timeBased, locationBased;
	Button next;
	SharedPreferences prefs;
	static Context abc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		abc = this;
		setContentView(R.layout.select_profile_management_attributes);
		init();
	}

	public void init() {
		timeBased = (CheckBox) findViewById(R.id.cbTimeBased);
		timeBased.setOnCheckedChangeListener(this);

		locationBased = (CheckBox) findViewById(R.id.cbLocationBased);
		locationBased.setOnCheckedChangeListener(this);

		next = (Button) findViewById(R.id.bNext_selectProfileManagerAtt);
		next.setOnClickListener(this);
	}

	@Override
	public void onCheckedChanged(CompoundButton view, boolean checked) {
		// TODO Auto-generated method stub
		switch (view.getId()) {
		case R.id.cbTimeBased:
			if (checked) {
				Toast.makeText(getApplicationContext(), "Time Checked",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getApplicationContext(), "Time UnChecked",
						Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.cbLocationBased:
			if (checked) {
				Toast.makeText(getApplicationContext(), "Loc Checked",
						Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(getApplicationContext(), "Loc UnChecked",
						Toast.LENGTH_SHORT).show();
			}
			break;
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bNext_selectProfileManagerAtt:

			if (locationBased.isChecked() && timeBased.isChecked()) {
				// Some Hybrid Stuff
				// Intent i2 = new Intent(
				// "com.example.projectqwerty001.SELECTLOCATION");
				// startActivity(i2);
				Toast.makeText(getInstance(), "You Can Select only One",
						Toast.LENGTH_SHORT).show();
				break;
			}

			if (timeBased.isChecked()) {

				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				Editor e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_TIME_BASED, true);
				e.commit();

			} else {
				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				Editor e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_TIME_BASED, false);
				e.commit();
			}

			if (locationBased.isChecked()) {
				// Start the Map wala Activity

				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				Editor e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, true);
				e.commit();

				Intent myIntent = new Intent(
						"com.example.projectqwerty001.SELECTLOCATION");
				startActivity(myIntent);
			} else {
				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				Editor e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, false);
				e.commit();
			}

			// Finished putting the prefs

			if (!locationBased.isChecked() && !timeBased.isChecked()) {
				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				Editor e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, false);
				e.commit();

				prefs = getSharedPreferences(
						SplashActivity.SHARED_PREFERENCES_FILENAME,
						MODE_PRIVATE);
				e = prefs.edit();
				e.putBoolean(SplashActivity.KEY_FLAG_TIME_BASED, false);
				e.commit();

				startActivity(new Intent(
						"com.example.projectqwerty001.SETUPCOMPLETED"));
			}
			if (!locationBased.isChecked() && timeBased.isChecked()) {
				// prefs = getSharedPreferences(
				// SplashActivity.SHARED_PREFERENCES_FILENAME,
				// MODE_PRIVATE);
				// Editor e = prefs.edit();
				// e.putBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, false);
				// e.commit();
				//
				// prefs = getSharedPreferences(
				// SplashActivity.SHARED_PREFERENCES_FILENAME,
				// MODE_PRIVATE);
				// e = prefs.edit();
				// e.putBoolean(SplashActivity.KEY_FLAG_TIME_BASED, true);
				// e.commit();

				// Intent i = new Intent(getBaseContext(),
				// ProfileManagerService.class);
				// PendingIntent pi = PendingIntent.getService(this, 0, i, 0);
				// AlarmManager alarm = (AlarmManager)
				// getSystemService(Context.ALARM_SERVICE);
				// alarm.setRepeating(AlarmManager.RTC_WAKEUP, Calendar
				// .getInstance().getTimeInMillis(), 5 * 1000, pi);
				// Toast.makeText(getApplicationContext(),
				// "Profile Management Service Started",
				// Toast.LENGTH_SHORT).show();
				Intent i = new Intent(getBaseContext(),
						ProfileManagerService.class);
				PendingIntent pi = PendingIntent.getService(this, 0, i, 0);
				AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
				alarm.setRepeating(AlarmManager.RTC_WAKEUP, Calendar
						.getInstance().getTimeInMillis(), 5 * 1000, pi);
				Toast.makeText(getApplicationContext(),
						"Profile Management Service Started",
						Toast.LENGTH_SHORT).show();
				startActivity(new Intent(
						"com.example.projectqwerty001.SETUPCOMPLETED"));
			}
			if (locationBased.isChecked() && !timeBased.isChecked()) {
				// prefs = getSharedPreferences(
				// SplashActivity.SHARED_PREFERENCES_FILENAME,
				// MODE_PRIVATE);
				// Editor e = prefs.edit();
				// e.putBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, true);
				// e.commit();
				Intent i1 = new Intent(
						"com.example.projectqwerty001.SELECTLOCATION");
				startActivity(i1);
			}

			break;
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

	public static SelectProfileManagementAttributes getInstance() {
		return (SelectProfileManagementAttributes) abc;
	}
}
