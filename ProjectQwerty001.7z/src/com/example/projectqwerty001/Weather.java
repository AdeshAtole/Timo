package com.example.projectqwerty001;

public class Weather {
	String startTime, endTime, subjectName;
	public Weather(String startTime,String endTime,String subjectName){
		this.startTime = startTime;
		this.endTime = endTime;
		this.subjectName = subjectName;
	}
}
