package com.example.projectqwerty001;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class SelectUserType extends Activity implements OnClickListener {

	Button cr, stud;
	ImageButton icr, istud;
	TextView whoAreYou;
	SharedPreferences userPref;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		makeFullScreenActivity();
		setContentView(R.layout.selectusertype);
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		cr = (Button) findViewById(R.id.bCR);
		cr.setTypeface(SplashActivity.robotoLight);
		cr.setOnClickListener(this);

		stud = (Button) findViewById(R.id.bStudent);
		stud.setTypeface(SplashActivity.robotoLight);
		stud.setOnClickListener(this);

		icr = (ImageButton) findViewById(R.id.ibCR);
		icr.setOnClickListener(this);

		istud = (ImageButton) findViewById(R.id.ibStudent);
		istud.setOnClickListener(this);

		whoAreYou = (TextView) findViewById(R.id.tvWhoAreYou);
		whoAreYou.setTypeface(SplashActivity.robotoLight);
	}

	void makeFullScreenActivity() {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch (arg0.getId()) {
		case R.id.bCR:
		case R.id.ibCR:
			final AlertDialog confirmationCR = new AlertDialog.Builder(
					SelectUserType.this).create();
			confirmationCR.setTitle("Confirm your selection");
			confirmationCR
					.setMessage("You have selected CR.\nPress OK to Confirm.");
			confirmationCR.setButton("OK",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							Toast.makeText(getApplicationContext(),
									"Confirmed CR", Toast.LENGTH_LONG).show();

							userPref = getSharedPreferences(
									SplashActivity.SHARED_PREFERENCES_FILENAME,
									MODE_PRIVATE);
							SharedPreferences.Editor editor = userPref.edit();
							editor.putInt(SplashActivity.KEY_USER_TYPE,
									SplashActivity.USER_CR);
							editor.commit();
							Intent crIntent = new Intent(
									"com.example.projectqwerty001.ADDSUBJECTSACTIVITY");
							startActivity(crIntent);
						}
					});
			confirmationCR.setButton2("Cancel",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							Toast.makeText(getApplicationContext(),
									"Canceled CR", Toast.LENGTH_LONG).show();
							confirmationCR.cancel();
						}
					});
			confirmationCR.show();
			break;

		case R.id.bStudent:
		case R.id.ibStudent:
			final AlertDialog confirmationStudent = new AlertDialog.Builder(
					SelectUserType.this).create();
			confirmationStudent.setTitle("Confirm your selection");
			confirmationStudent
					.setMessage("You have selected Student.\nPress OK to Confirm.");
			confirmationStudent.setButton("OK",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							Toast.makeText(getApplicationContext(),
									"Confirmed Student", Toast.LENGTH_LONG)
									.show();
							userPref = getSharedPreferences(
									SplashActivity.SHARED_PREFERENCES_FILENAME,
									MODE_PRIVATE);
							SharedPreferences.Editor editor = userPref.edit();
							editor.putInt(SplashActivity.KEY_USER_TYPE,
									SplashActivity.USER_STUDENT);
							editor.commit();
							Intent studentIntent = new Intent(
									"com.example.projectqwerty001.ADDSUBJECTSACTIVITY");
							startActivity(studentIntent);
						}
					});
			confirmationStudent.setButton2("Cancel",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							Toast.makeText(getApplicationContext(),
									"Canceled Student", Toast.LENGTH_LONG)
									.show();
							confirmationStudent.cancel();
						}
					});
			confirmationStudent.show();
			break;
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

}