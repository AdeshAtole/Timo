package com.example.projectqwerty001;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class NoSubjectsAdded extends Activity {

	RelativeLayout rlMain;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.no_subjects_added);
		init();
	}

	private void init() {
		rlMain = (RelativeLayout) findViewById(R.id.rlParentAddSubjectsRevised);
		rlMain.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(),
						"View Clicked. Now starting AddNewSubject",
						Toast.LENGTH_SHORT).show();
				Intent i = new Intent(
						"com.example.projectqwerty001.ADDNEWSUBJECT");
				startActivityForResult(i, 1);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Intent i = new Intent("com.example.projectqwerty001.SUBJECTLIST");
			startActivity(i);
			finish();
		}
	}
}