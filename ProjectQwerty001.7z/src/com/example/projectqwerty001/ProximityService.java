package com.example.projectqwerty001;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.IBinder;

public class ProximityService extends Service {

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		SharedPreferences prefs = getSharedPreferences(
				SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
		if (prefs.getBoolean(SplashActivity.KEY_FLAG_LOCATION_BASED, false) == true) {
			LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
			Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

			AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);

			if (l == null) {
				// Toast.makeText(getApplicationContext(), "GPS not Enabled",
				// Toast.LENGTH_SHORT).show();
				// stopSelf();
				// MainActivity.a = false;
				return START_STICKY;
			}
			double lat = 37.422006;
			double lon = -122.084095;
			Location n = new Location(LocationManager.GPS_PROVIDER);
			n.setLatitude(lat);
			n.setLongitude(lon);
			if (l.distanceTo(n) < prefs.getInt(
					SplashActivity.KEY_PROXIMITY_RADIUS, 1000)) {
				// MainActivity.res.setText("Entering " + l.distanceTo(n));
				if (am.getRingerMode() != AudioManager.RINGER_MODE_VIBRATE) {
					am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
				}
			} else {
				// MainActivity.res.setText("Exiting " + l.distanceTo(n));
				if (am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) {
					am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
				}
			}
		}
		return START_STICKY;
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}
