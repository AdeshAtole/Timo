package com.example.projectqwerty001;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.util.Log;

@SuppressLint("SimpleDateFormat")
public class TimeHandler {
	public static String convertTo24Hr(String _12HrTime) {
		// TODO For converting 12 Hr Time "HH:mm a" into 24 Hr Time "HH:mm"
		SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
		SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
		Date date;
		try {
			date = parseFormat.parse(_12HrTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return displayFormat.format(date);
	}

	public static Date convertToDate12Hr(String stTime) {
		SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
		Date date;
		try {
			date = parseFormat.parse(stTime);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return date;
	}

	public static Date convertToDate24Hr(String stTime) {
		SimpleDateFormat parseFormat = new SimpleDateFormat("HH:mm");
		Date date;
		try {
			date = parseFormat.parse(stTime);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return date;
	}

	public static boolean isConflict(TimeRange tr1, TimeRange tr2) {
		if (tr2.startTime.after(tr1.startTime)
				&& tr2.startTime.before(tr1.endTime)) {
			return true;
		}
		if (tr2.endTime.after(tr1.startTime) && tr2.endTime.before(tr1.endTime)) {
			return true;
		}
		if (tr2.startTime.before(tr1.startTime)
				&& tr2.endTime.after(tr1.endTime)) {
			return true;
		}
		if (tr2.startTime.after(tr1.startTime)
				&& tr2.endTime.before(tr1.endTime)) {
			return true;
		}
		return false;
	}

	public static TimetableEntryInformation currentLecture(Context c) {
		@SuppressWarnings("unused")
		SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm");
		SimpleDateFormat parseFormat = new SimpleDateFormat("hh:mm a");
		Date d = new Date();
		int day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
		String sD = parseFormat.format(d);
		Date currentTime = null;
		try {
			currentTime = parseFormat.parse(sD);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		TimetableDatabase ttdb = new TimetableDatabase(c);
		ArrayList<TimetableEntryInformation> ttInfoList = new ArrayList<TimetableEntryInformation>();
		ttdb.open();
		try {
			ttInfoList = ttdb.getSubjects(TimetableDatabase.getTableName(day));
			Log.d("MYTAG", "Day="+day);
		} catch (SQLiteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ttdb.close();

		for (int i = 0; i < ttInfoList.size(); i++) {
			Date startTime = ttInfoList.get(i).getStartTime();
			Date endTime = ttInfoList.get(i).getEndTime();
			if (currentTime.after(startTime) && currentTime.before(endTime)) {
				return ttInfoList.get(i);
			}
		}
		return null;
	}
}