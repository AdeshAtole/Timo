package com.example.projectqwerty001;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class SubjectList extends Activity implements OnClickListener {

	// String[] subs = new String[] { "sub 1", "sub 2", "sub 3" };
	ArrayList<String> subList = new ArrayList<String>();
	Button addNewSubject, next;

	static SubjectList subjectList;

	public static final String KEY_SUBJECT_NAME = "SUBJECT_NAME";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		makeFullScreenActivity();
		setContentView(R.layout.subjects_list);
		subjectList = this;
		init();

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		ApplicationDatabase ad = new ApplicationDatabase(this);
		ad.open();
		subList = ad.getSubjects();
		ad.close();

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, subList);

		ListView lv = (ListView) findViewById(R.id.lvSubjectList);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String selectedSubjectName = subList.get(position);
				Toast.makeText(getApplicationContext(),
						"" + selectedSubjectName, Toast.LENGTH_SHORT).show();
				Bundle bundle = new Bundle();
				bundle.putString(KEY_SUBJECT_NAME, selectedSubjectName);
				Intent i = new Intent(SubjectList.this, EditSubject.class);
				i.putExtras(bundle);
				startActivity(i);
			}
		});
		lv.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(),
						"Long Click : " + subList.get(position),
						Toast.LENGTH_SHORT).show();
				return false;
			}
		});
	}

	private void init() {
		// TODO Auto-generated method stub
		SharedPreferences prefs = getSharedPreferences(
				SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
		boolean setupStatus = prefs.getBoolean(
				SplashActivity.KEY_SETUP_COMPLETED, false);
		addNewSubject = (Button) findViewById(R.id.bAddNewSubject);
		addNewSubject.setOnClickListener(this);

		next = (Button) findViewById(R.id.bSubjectListNext);
		next.setOnClickListener(this);
		if (setupStatus == true) {
			next.setVisibility(Button.GONE);
		}
	}

	void makeFullScreenActivity() {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch (arg0.getId()) {
		case R.id.bAddNewSubject:
			Intent intent = new Intent(
					"com.example.projectqwerty001.ADDNEWSUBJECT");
			startActivity(intent);
			break;
		case R.id.bSubjectListNext:

			Intent intent2 = new Intent(
					"com.example.projectqwerty001.NEWTIMETABLEENTRY");
			startActivity(intent2);
			// finish();
			break;
		}
	}

	public static SubjectList getInstance() {
		return subjectList;
	}
}
