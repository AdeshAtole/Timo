package com.example.projectqwerty001;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateNewNotice extends Activity implements OnClickListener {
	EditText subject, body;
	Button send;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

	// DbxFileSystem dbxfs;
	// DbxAccountManager mdbxacctmgr = DbxAccountManager.getInstance(
	// getApplicationContext(), SplashActivity.DROPBOX_APP_KEY,
	// SplashActivity.DROPBOX_APP_SECRET);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_notice);
		// try {
		// dbxfs = DbxFileSystem.forAccount(mdbxacctmgr.getLinkedAccount());
		// } catch (Unauthorized e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// init();
	}

	private void init() {
		subject = (EditText) findViewById(R.id.etNoticeSubject);
		body = (EditText) findViewById(R.id.etNoticeBody);
		Log.i("DBX", "in inin(");
		send = (Button) findViewById(R.id.bSendNotice);
		send.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bSendNotice:
			NoticeData nd = new NoticeData(subject.getText().toString(), body
					.getText().toString());
			ObjectOutputStream oos = null;
			FileOutputStream fos = null;
			String time = sdf.format(new Date());
			try {
				fos = new FileOutputStream(SplashActivity.APPLICATION_PATH
						+ "/_notice/" + time + ".n");
				oos = new ObjectOutputStream(fos);
				oos.writeObject(nd);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					oos.close();
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// DbxFile notice = null;
			// try {
			// notice = dbxfs.create(new DbxPath("notice"));
			// notice.writeFromExistingFile(new File(
			// SplashActivity.APPLICATION_PATH + "/_notice/" + time
			// + ".n"), false);
			// Log.i("DBX", "in try");
			// } catch (Exception e) {
			// e.printStackTrace();
			// } finally {
			// notice.close();
			// }

			Toast.makeText(getApplicationContext(), "Notice Sent",
					Toast.LENGTH_SHORT).show();
			finish();
			break;
		}
	}
}