package com.example.projectqwerty001;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SetupCompleted extends Activity implements OnClickListener {

	Button finishSetup;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setup_completed);
		init();
	}

	public void init() {
		finishSetup = (Button) findViewById(R.id.bFinishSetup);
		finishSetup.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bFinishSetup:
			// HP
			SharedPreferences prefs = getSharedPreferences(
					SplashActivity.SHARED_PREFERENCES_FILENAME, MODE_PRIVATE);
			Editor e = prefs.edit();
			e.putBoolean(SplashActivity.KEY_SETUP_COMPLETED, true);
			e.commit();
			Intent i = new Intent("com.example.projectqwerty001.HOMESCREEN");
			startActivity(i);
			finish();
			break;
		}
	}
}
