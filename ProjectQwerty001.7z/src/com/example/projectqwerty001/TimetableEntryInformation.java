package com.example.projectqwerty001;

import java.util.Date;

public class TimetableEntryInformation {
	private String subjectName;
	Date startTime, endTime;

	public TimetableEntryInformation() {
		// TODO Auto-generated constructor stub
		subjectName = null;
		startTime = null;
		endTime = null;
	}

	public TimetableEntryInformation(Date startTime, Date endTime,
			String subjectName) {
		// TODO Auto-generated constructor stub
		this.subjectName = subjectName;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public void setEntry(Date startTime, Date endTime, String subjectName) {
		this.subjectName = subjectName;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		return endTime;
	}
}
