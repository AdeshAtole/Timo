package com.example.projectqwerty001;

import java.io.Serializable;

public class TimetableEntry implements Serializable {
	public static final int OPERATION_INSERT = 0;
	public static final int OPERATION_DELETE = 1;
	public static final int OPERATION_UPDATE = 2;

	TimetableEntryInformation ttInfo;
	int operation;
	int day;

	public TimetableEntry(TimetableEntryInformation ttInfo, int operation,
			int day) {
		// TODO Auto-generated constructor stub
		this.ttInfo = ttInfo;
		this.operation = operation;
		this.day = day;
	}

	public TimetableEntryInformation getTtInfo() {
		return ttInfo;
	}

	public int getOperation() {
		return operation;
	}

	public int getDay() {
		return day;
	}
}
