package com.example.projectqwerty001;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

//Class for handling databases
public class ApplicationDatabase {
	public static final String KEY_ROW_ID = "ROW_ID";
	public static final String KEY_SUBJECT_NAME = "SUBJECT_NAME";
	public static final String KEY_SUBJECT_DESCRIPTION = "SUBJECT_DESCRIPTION";

	public static final String DATABASE_NAME = "TIMO_DATABASE";
	public static final String TABLE_NAME_SUBJECT_TABLE = "TABLE_NAME_SUBJECT";
	// public static final String TABLE_NAME_TIME_TABLE = "TIME_TABLE_TABLE"; //
	// Table
	// Not
	// Created
	// (Only
	// declaration
	// for
	// now)
	public static final int DATABASE_VERSION = 1;

	private DbHelper ourHelper;
	private Context ourContext;
	private SQLiteDatabase ourDatabase;

	public ApplicationDatabase(Context c) {
		// TODO Auto-generated constructor stub
		ourContext = c;
	}

	public ApplicationDatabase open() throws SQLException {
		ourHelper = new DbHelper(ourContext);
		ourDatabase = ourHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		ourHelper.close();
	}

	public long createEntry(String subjectName, String description)
			throws SQLException, SQLiteConstraintException {
		ContentValues cv = new ContentValues();
		cv.put(KEY_SUBJECT_NAME, subjectName);
		cv.put(KEY_SUBJECT_DESCRIPTION, description);
		return ourDatabase.insert(TABLE_NAME_SUBJECT_TABLE, null, cv);
	}

	public String getData() {
		String columns[] = new String[] { KEY_ROW_ID, KEY_SUBJECT_NAME,
				KEY_SUBJECT_DESCRIPTION };
		Cursor c = ourDatabase.query(TABLE_NAME_SUBJECT_TABLE, columns, null,
				null, null, null, null);
		String result = "";
		int iRow = c.getColumnIndex(KEY_ROW_ID);
		int iSubjectName = c.getColumnIndex(KEY_SUBJECT_NAME);
		int iDesc = c.getColumnIndex(KEY_SUBJECT_DESCRIPTION);

		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			result = result + c.getString(iRow) + " "
					+ c.getString(iSubjectName) + " " + c.getString(iDesc)
					+ "\n";
		}

		return result;
	}

	public int dropSubjectTable() {
		try {
			ourDatabase.execSQL("DROP TABLE IF EXISTS "
					+ TABLE_NAME_SUBJECT_TABLE + ";");
			// onCreate(ourDatabase);
			Log.d("SUCC", "Query Success");
		} catch (SQLException e) {
			// TODO: handle exception
			Log.d("DB", "Q Error");
		}
		return 1;
	}

	public String getSubjectName(int position) throws SQLException {
		String columns[] = new String[] { KEY_ROW_ID, KEY_SUBJECT_NAME,
				KEY_SUBJECT_DESCRIPTION };
		Cursor c = ourDatabase.query(TABLE_NAME_SUBJECT_TABLE, columns, null,
				null, null, null, null);
		// if (c != null) {
		// c.moveToFirst();
		// String name = c.getString(c.getColumnIndex(KEY_SUBJECT_NAME));
		// return name;
		// }
		// return null;
		c.moveToPosition(position);
		String name = c.getString(c.getColumnIndex(KEY_SUBJECT_NAME));
		return name;
	}

	public String getSubjectDescription(long l) throws SQLException {
		String columns[] = new String[] { KEY_ROW_ID, KEY_SUBJECT_NAME,
				KEY_SUBJECT_DESCRIPTION };
		Cursor c = ourDatabase.query(TABLE_NAME_SUBJECT_TABLE, columns,
				KEY_ROW_ID + "=" + l, null, null, null, null);
		if (c != null) {
			c.moveToFirst();
			String desc = c
					.getString(c.getColumnIndex(KEY_SUBJECT_DESCRIPTION));
			return desc;
		}
		return null;
		// returns Description if Index is Passed
	}

	public String getSubjectDescription(String subjectName) throws SQLException {
		String columns[] = new String[] { KEY_ROW_ID, KEY_SUBJECT_NAME,
				KEY_SUBJECT_DESCRIPTION };
		Cursor c = ourDatabase.query(TABLE_NAME_SUBJECT_TABLE, columns,
				KEY_SUBJECT_NAME + "=" + "\"" + subjectName + "\"", null, null,
				null, null);
		if (c != null) {
			c.moveToFirst();
			String desc = c
					.getString(c.getColumnIndex(KEY_SUBJECT_DESCRIPTION));
			return desc;
		}
		return null;
		// Returns Subject description if Subject name is Passed
	}

	public void updateEntry(long lRow, String newSubjectName, String description)
			throws SQLException {
		ContentValues cv = new ContentValues();
		cv.put(KEY_SUBJECT_NAME, newSubjectName);
		cv.put(KEY_SUBJECT_DESCRIPTION, description);
		ourDatabase.update(TABLE_NAME_SUBJECT_TABLE, cv, KEY_ROW_ID + "="
				+ lRow, null);
	}

	public void updateEntry(String oldSubjectName, String newSubjectName,
			String description) throws SQLException, SQLiteConstraintException {
		ContentValues cv = new ContentValues();
		cv.put(KEY_SUBJECT_NAME, newSubjectName);
		cv.put(KEY_SUBJECT_DESCRIPTION, description);
		ourDatabase.update(TABLE_NAME_SUBJECT_TABLE, cv, KEY_SUBJECT_NAME + "="
				+ "\"" + oldSubjectName + "\"", null);
	}

	public void deleteEntry(long rowId) throws SQLException {
		ourDatabase.delete(TABLE_NAME_SUBJECT_TABLE, KEY_ROW_ID + "=" + rowId,
				null);
	}

	public int deleteEntry(String subjectName) throws SQLException {
		return ourDatabase.delete(TABLE_NAME_SUBJECT_TABLE, KEY_SUBJECT_NAME
				+ "=" + "\"" + subjectName + "\"", null);
	}

	public long getNumberOfEntries() {
		// STUB
		long numRows = DatabaseUtils.longForQuery(ourDatabase,
				"SELECT COUNT(*) FROM " + TABLE_NAME_SUBJECT_TABLE, null);
		return numRows;
	}

	public ArrayList<String> getSubjects() {
		ArrayList<String> subjectList = new ArrayList<String>();
		String columns[] = new String[] { KEY_ROW_ID, KEY_SUBJECT_NAME,
				KEY_SUBJECT_DESCRIPTION };
		Cursor c = ourDatabase.query(TABLE_NAME_SUBJECT_TABLE, columns, null,
				null, null, null, null);
		for (c.moveToFirst(); !c.isAfterLast(); c.moveToNext()) {
			subjectList.add(c.getString(c.getColumnIndex(KEY_SUBJECT_NAME)));
		}
		return subjectList;
	}

	private static class DbHelper extends SQLiteOpenHelper {

		DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL("CREATE TABLE " + TABLE_NAME_SUBJECT_TABLE + " ("
					+ KEY_ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
					+ KEY_SUBJECT_NAME + " TEXT UNIQUE NOT NULL ,"
					+ KEY_SUBJECT_DESCRIPTION + " TEXT" + ");");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
			// TODO Auto-generated method stub
			try {
				db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_SUBJECT_TABLE
						+ ";");
				onCreate(db);
				Log.d("DB_SUCCESS", "Query Success");
			} catch (SQLException e) {
				// TODO: handle exception
				Log.d("DB_FAILURE", "Query Error");
			}
		}

	}
}