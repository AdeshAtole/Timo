package com.example.projectqwerty001;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class SelectLocation extends MapActivity {

	MapView mv;
	SharedPreferences pref;
	Drawable d;
	List<Overlay> overlayList;
	TextView addressLine;
	ImageButton search;
	Button next;
	int size;
	float lat = 0, lon = 0;
	static Context abc;
	Geocoder geocoder;
	List<Address> addresses;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		abc = this;
		setContentView(R.layout.select_location);
		init();
		mv = (MapView) findViewById(R.id.mv1);
		mv.setBuiltInZoomControls(true);
		overlayList = mv.getOverlays();
		size = overlayList.size();
		Touchy t = new Touchy();
		overlayList.add(t);

	}

	public void init() {
		d = getResources().getDrawable(R.drawable.google_maps_pin);

		addressLine = (TextView) findViewById(R.id.tvAddress);

		search = (ImageButton) findViewById(R.id.ibSearch_selectLocation);
		search.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder editAlert = new AlertDialog.Builder(
						SelectLocation.this);
				editAlert.setTitle("Search");
				editAlert.setMessage("Type location to search.");
				final EditText input = new EditText(SelectLocation.this);
				LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.FILL_PARENT,
						LinearLayout.LayoutParams.WRAP_CONTENT);
				input.setLayoutParams(lp);
				editAlert.setView(input);
				editAlert.setPositiveButton("Search",
						new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								// Geocoder geocoder = new
								// Geocoder(SelectLocation.this,
								// Locale.getDefault());
								// geocoder.
								geocoder = new Geocoder(SelectLocation.this);
								addresses = null;
								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										try {
											addresses = geocoder
													.getFromLocationName(input
															.getText()
															.toString(), 1);
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										if (addresses != null) {
											if (addresses.size() > 0) {
												double lat, lon;
												lat = addresses.get(0)
														.getLatitude();
												lon = addresses.get(0)
														.getLongitude();
												// mv.sc
												MapController mc = mv
														.getController();
												GeoPoint g = new GeoPoint(
														(int) (lat / 1E6),
														(int) (lon / 1E6));
												mc.animateTo(g);
												Toast.makeText(
														getApplicationContext(),
														"Found!",
														Toast.LENGTH_SHORT);
											}
										}
									}
								}).start();

								Toast.makeText(getApplicationContext(),
										input.getText().toString(),
										Toast.LENGTH_SHORT).show();
							}
						});
				editAlert.show();
			}
		});
		next = (Button) findViewById(R.id.bNext_SelectLocation);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (lat != 0 && lon != 0) {
					pref = getSharedPreferences(
							SplashActivity.SHARED_PREFERENCES_FILENAME,
							MODE_PRIVATE);
					Editor editor = pref.edit();
					editor.putFloat(SplashActivity.KEY_LATITUDE, lat);
					editor.putFloat(SplashActivity.KEY_LONGITUDE, lon);
					editor.commit();

					pref = getSharedPreferences(
							SplashActivity.SHARED_PREFERENCES_FILENAME,
							MODE_PRIVATE);
					Toast.makeText(
							getApplicationContext(),
							"Selected Location : ("
									+ pref.getFloat(
											SplashActivity.KEY_LATITUDE, 0)
									+ pref.getFloat(
											SplashActivity.KEY_LONGITUDE, 0)
									+ ")", Toast.LENGTH_LONG).show();
					Intent i = new Intent(
							"com.example.projectqwerty001.SETRADIUS");
					startActivity(i);
				} else {
					Toast.makeText(getApplicationContext(),
							"Select a proper Location", Toast.LENGTH_SHORT)
							.show();
				}
			}
		});
		search.setVisibility(Button.GONE);
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	class Touchy extends Overlay {

		@Override
		public boolean onTap(GeoPoint p, MapView mapView) {
			// TODO Auto-generated method stub
			lat = (float) (p.getLatitudeE6() / 1E6);
			lon = (float) (p.getLongitudeE6() / 1E6);

			OverlayItem o = new OverlayItem(p, "Hello", "Hello");
			CustomPinpoint customPinpoint = new CustomPinpoint(d,
					SelectLocation.this);
			customPinpoint.insertPinpoint(o);
			if (overlayList.size() > size + 1) {
				overlayList.remove((overlayList.size() - 1));
			}
			overlayList.add(customPinpoint);

			geocoder = new Geocoder(SelectLocation.this, Locale.getDefault());
			addresses = null;
			final Handler h = new Handler();

			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					h.post(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								addresses = geocoder.getFromLocation(
										(double) lat, (double) lon, 1);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							String address;

							if (addresses != null) {
								address = addresses.get(0).getAddressLine(0);
								addressLine.setText("Address : " + address);
							} else {
								Toast.makeText(
										getApplicationContext(),
										"Address not Available for this location",
										Toast.LENGTH_SHORT).show();
								addressLine
										.setText("Tap on the location of Your College");
							}
						}
					});

				}
			}).start();

			return true;
		}

	}

	static SelectLocation getInstance() {
		return (SelectLocation) abc;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

}